
    document.addEventListener('DOMContentLoaded', function() {
      const newsItems = document.querySelectorAll('.news-item');
      const closeIcons = document.querySelectorAll('.close-icon');
      let currentIndex = 0;

      function showNextNewsItem() {
        const previousIndex = currentIndex;
        currentIndex = (currentIndex + 1) % newsItems.length;

        newsItems[previousIndex].classList.remove('active');
        newsItems[previousIndex].classList.add('previous');
        newsItems[currentIndex].classList.remove('next');
        newsItems[currentIndex].classList.add('active');

        setTimeout(() => {
          newsItems[previousIndex].classList.remove('previous');
          newsItems[previousIndex].classList.add('next');
        }, 1000);
      }

      setInterval(showNextNewsItem, 2000); // Change news item every 3 seconds

      closeIcons.forEach((icon, index) => {
        icon.addEventListener('click', () => {
          newsItems[index].style.display = 'none';
          setTimeout(() => {
            newsItems[index].style.display = 'flex';
            if (newsItems[index].classList.contains('previous')) {
              newsItems[index].classList.remove('previous');
              newsItems[index].classList.add('next');
            }
            if (newsItems[index].classList.contains('active')) {
              newsItems[index].classList.remove('active');
              newsItems[index].classList.add('next');
              currentIndex = (currentIndex + 1) % newsItems.length;
              newsItems[currentIndex].classList.add('active');
            }
          }, 2000); // Show the hidden item after 3 seconds
        });
      });
    });




  $(document).ready(function(){
    $('.blog-slider').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: true,
        
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    
                }
            },
            {
                breakpoint: 600,
                dots: true,
                arrows: false,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ],
        prevArrow: '<button class="slick-prev slick-arrow"><i class="ion-ios-arrow-back"></i></button>',
        nextArrow: '<button class="slick-next slick-arrow"><i class="ion-ios-arrow-forward"></i></button>',
    });
});


$(document).ready(function(){
  $('.slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          dots: true,
          arrows: false
        }
      }

    ],
    prevArrow: '<button class="slick-prev slick-arrow"><i class="ion-ios-arrow-back"></i></button>',
    nextArrow: '<button class="slick-next slick-arrow"><i class="ion-ios-arrow-forward"></i></button>',
  });
});



document.getElementById('decrease').addEventListener('click', function() {
  let quantity = document.getElementById('quantity').value;
  if (quantity > 1) {
    document.getElementById('quantity').value = --quantity;
  }
});

document.getElementById('increase').addEventListener('click', function() {
  let quantity = document.getElementById('quantity').value;
  document.getElementById('quantity').value = ++quantity;
});



$(document).ready(function(){
  $('.product-slider').slick({
      dots: true,
      infinite: true,
      speed: 300,
      slidesToShow: 4,
      slidesToScroll: 4,
      responsive: [
          {
              breakpoint: 1024,
              settings: {
                  slidesToShow: 3,
                  slidesToScroll: 3,
                  infinite: true,
                  dots: true
              }
          },
          {
              breakpoint: 800,
              settings: {
                  slidesToShow: 2,
                  slidesToScroll: 2
              }
          },
          {
              breakpoint: 480,
              settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
              }
          }
      ],
      prevArrow: '<button class="slick-prev slick-arrow"><i class="ion-ios-arrow-back"></i></button>',
      nextArrow: '<button class="slick-next slick-arrow"><i class="ion-ios-arrow-forward"></i></button>',
  });
});


